'use strict';

/* Services */
var serverUrl = "http\://localhost";
var serverPort = "8080";

angular.module("myAngular.services", ['ngResource'])

	.factory("PersonService", function ($q, $resource) {
		return {
			// Add a person
			savePerson: function (person) {
				var deferred = $q.defer();
				$resource(serverUrl + "\:" + serverPort + "/data/person")
					.save(person, function (data) {
						deferred.resolve(data);
					});
				return deferred.promise;
			},

			// Get one person
			getPersonDetail: function (id) {
				var deferred = $q.defer();
				$resource(serverUrl + "\:" + serverPort + "/data/person/:id", {id: id}, {
					query: {
						method: 'GET',
						params: id,
						isArray: false
					}
				});
				return deferred.promise;
			},

			// Get a list of persons
			getPersonList: function () {
				var deferred = $q.defer();
				$resource(serverUrl + "\:" + serverPort + "/data/person", {}, {
					query: {
						method: 'GET',
						param: {},
						isArray: true
					}
				});
				return deferred.promise;
			}

		}
	});
