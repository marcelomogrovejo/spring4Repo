'use strict';

/* Controllers */


angular.module("myAngular.controllers", [])

	// Clear browser cache (in development mode)
	//
	// http://stackoverflow.com/questions/14718826/angularjs-disable-partial-caching-on-dev-machine
	.run(function ($rootScope, $templateCache) {
	    $rootScope.$on("$viewContentLoaded", function () {
	        $templateCache.removeAll();
	    });
	})

	.controller("HomeController", ['$scope', function ($scope) {
		$scope.title = 'Home Page';
	}])
	
	//FIXME: figure out how to pass the customized id
	.controller("PersonDetailController", ['$scope', "PersonService", function ($scope, PersonService) {
//		var id = $locationProvider.search().id;
	var id = 2;	
//		console.log('id: ' + id);
		
		$scope.getPerson = function(id) {
			PersonService.getPersonDetail(id).then(function(data) {
				$scope.firstname = data.firstName;
				$scope.lastname = data.lastName;
			})
		};
	}])
	
	.controller("PersonListController", ['$scope', "PersonService", function ($scope, PersonService) {
		$scope.getPersons = function() {
			PersonsService.getPersonList().then(function(data) {
				$scope.persons = data;
			})
		};
	}])
	
	.controller("AddPersonController", ['$scope', "PersonService", function($scope, PersonService) {
		// Save new person
		$scope.update = function(person) {
			PersonSaveFactory.savePerson( person ).then(function(data) {
				console.log(data.firstName);
			});
		};
		
		// Reset the form
		$scope.reset = function() {
			$scope.person = angular.copy($scope.master);
		};
		$scope.reset();
	}])
	
	.controller("HelpController", ['$scope', function ($scope) {
		$scope.title = 'Help Section';
	}])
	;
